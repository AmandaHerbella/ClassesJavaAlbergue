package br.edu.faeterj;

public class Reserva{
  private int IDReserva;
  private int IDCliente;
  private int IDVaga;
  private String dataInicio;
  private String dataFim;

  public Reserva(int IDReserva, int IDCliente, int IDVaga, String dataInicio, String dataFim){
    this.IDReserva = IDReserva;
    this.IDCliente = IDCliente;
    this.IDVaga = IDVaga;
    this.dataInicio = dataInicio;
    this.dataFim = dataFim;

    public int getIDReserva(){
      return IDReserva;
    }
    public int setIDReserva(int IDReserva){
      this.IDReserva = IDReserva;
    }
    public int getIDCliente(){
      return IDCliente;
    }
    public int setIDCliente(int IDCliente){
      this.IDCliente = IDCliente;
    }
    public int getIDVaga(){
      return IDVaga;
    }
    public int setIDVaga(int IDVaga){
      this.IDVaga = IDVaga;
    }
    public String getDataInicio(){
      return dataInicio;
    }
    public String setDataInicio(String dataInicio){
      this.dataInicio = dataInicio;
    }
    public String getDataFim(){
      return dataFim;
    }
  }
}