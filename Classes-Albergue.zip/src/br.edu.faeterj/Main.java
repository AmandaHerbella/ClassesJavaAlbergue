
// import static org.junit.jupiter.api.Assertions.assertEquals;

// import org.junit.jupiter.api.Test;
package br.edu.faeterj;
import java.util.Scanner;

public class Main {
  public static void main(String[] args) {
    String nome = " ";
    String CPF = " ";
    String endereco = " ";
    String email = " ";
    String status = " ";
    String posicao = " ";
    String tipo = " ";
    String dataInicio = " ";
    String dataFim = " ";

    Scanner sc = new Scanner(System.in);
    System.out.println("Digite o nome do cliente: ");
    nome = sc.nextLine();
    System.out.println("Digite o CPF do cliente: ");
    CPF = sc.nextLine();
    System.out.println("Digite o endereço do cliente: ");
    endereco = sc.nextLine();
    System.out.println("Digite o email do cliente: ");
    email = sc.nextLine();
    System.out.println("Digite o telefone do cliente: ");
  }

}

  // @Test
  // void addition() {
  //     assertEquals(2, 1 + 1);
  // }
}