package br.edu.faeterj;
  
public class Cliente{
  private int IDCliente;
  private String nome;
  private String CPF;
  private String endereco;
  private String email;
  private int telefone;
  
    public Cliente(int IDCliente, String nome, String CPF, String endereco, String email, int telefone){
      this.IDCliente = IDCliente;
      this.nome = nome;
      this.CPF = CPF;
      this.endereco = endereco;
      this.email = email;
      this.telefone = telefone;
    }
    public int getIDCliente(){
      return IDCliente;
    }
    public int setIDCliente(int IDCliente){
      this.IDCliente = IDCliente;
    }
    public String getNome(){
      return nome;
    }
    public String setNome(String nome){
      this.nome = nome;
    }
    public String getCPF(){
      return CPF;
    }
    public String setCPF(String CPF){
      this.CPF = CPF;
    }
    public String getEndereco(){
      return endereco;
    }
    public String setEndereco(String endereco){
      this.endereco = endereco;
    }
    public String getEmail(){
      return email;
    }
    public String setEmail(String email){
      this.email = email;
    }
    public int getTelefone(){
      return telefone;
    }
    public int setTelefone(int telefone){
      this.telefone = telefone;
    }
}