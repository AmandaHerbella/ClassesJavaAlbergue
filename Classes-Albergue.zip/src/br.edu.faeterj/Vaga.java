package br.edu.faeterj;

public class Vaga{
  private int IDVaga;
  private int IDQuarto;
  private String status;
  private String posicao;
  private String tipo;

  public Vaga(int IDVaga, int IDQuarto, String status, String posicao, String tipo){
    this.IDVaga = IDVaga;
    this.IDQuarto = IDQuarto;
    this.status = status;
    this.posicao = posicao;
    this.tipo = tipo;

    public int getIDVaga(){
      return IDVaga;
    }
    public int setIDVaga(int IDVaga){
      this.IDVaga = IDVaga;
    }
    public int getIDQuarto(){
      return IDQuarto;
    }
    public int setIDQuarto(int IDQuarto){
      return IDQuarto;
    }
    public String getStatus(){
      return status;
    }
    public String setStatus(String status){
      this.status = status;
    }
    public String getPosicao(){
      return posicao;
    }
    public String setPosicao(String posicao){
      this.posicao = posicao;
    }
    public String getTipo(){
      return tipo;
    }
    public String setTipo(){
      this.tipos = tipo;
    }
  }
}